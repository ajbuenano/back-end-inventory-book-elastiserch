package com.unir.elastiserch.service;

import com.unir.elastiserch.controller.model.BooksQueryResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.unir.elastiserch.data.DataAccessRepository;
import com.unir.elastiserch.data.model.Book;
import com.unir.elastiserch.controller.model.CreateBookRequest;

@Service
@RequiredArgsConstructor
public class BooksServiceImpl implements BooksService {

	private final DataAccessRepository repository;

	@Override
	public BooksQueryResponse getBooks(String name, String description, String country, Boolean aggregate) {
		//Ahora por defecto solo devolvera productos visibles
		return repository.findBooks(name, description, country, aggregate);
	}

	@Override
	public Book getBook(String bookId) {
		return repository.findById(bookId).orElse(null);
	}

	@Override
	public Boolean removeBook(String bookId) {

		Book book = repository.findById(bookId).orElse(null);
		if (book != null) {
			repository.delete(book);
			return Boolean.TRUE;
		} else {
			return Boolean.FALSE;
		}
	}

	@Override
	public Book createBook(CreateBookRequest request) {

		if (request != null && StringUtils.hasLength(request.getTitle().trim())
				&& StringUtils.hasLength(request.getDescription().trim())
				&& StringUtils.hasLength(request.getAuthor().trim()) && request.getVisible() != null) {
				
				Book book = Book.builder().title(request.getTitle()).description(request.getDescription())
						.visible(request.getVisible()).build();

			return repository.save(book);
		} else {
			return null;
		}
	}

}
